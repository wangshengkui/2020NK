/** Automatically generated file. DO NOT MODIFY */
package com.hanheng.horserace;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}